import java.util.Scanner;    
public class calc {    
    public static void main (String args[]){   
   
        short operation;
        double num1 = 0, num2 = 0, num = 0;
        Scanner input = new Scanner(System.in);
        
        do {
             System.out.println("Enter the desired operation:");
             System.out.println("  1. sum");      
             System.out.println("  2. Subtraction");      
             System.out.println("  3. Multiplication");      
             System.out.println("  4. Division");
             System.out.println("  5. Square");
             System.out.println("  0. Exit");
             System.out.print("Operation: ");
             operation = input.nextShort();
             
             if (operation == 0) {
            	 System.out.println("See you soon, good studies!");
            	 break;
             }
             
             if (!OperationExists(operation)) {
            	 continue;
             }
             if (operation == 5) {
                 System.out.print("Enter the value: ");
                 num = input.nextDouble();
             } else {
                System.out.print("Enter the first value: ");
                num1 = input.nextDouble();
             
                System.out.print("Enter the second value: ");
                num2 = input.nextDouble();
             }
                if (!ValidatedInputData(operation, num1, num2)) {
            	 continue;
             }
                
                if (!ValidatedInputDataSquare(operation, num)) {
            	 continue;
             }
             

             if(operation == 5){
                System.out.println("RESULT: The result of the operation " + getNameOperation(operation) +  " is "  + Math.pow(num, 2) + "\n");

             } else {
   
                System.out.println("RESULT: The result of the operation " + getNameOperation(operation) + " is " + Calculate(operation, num1, num2) + "\n");

             }
        } while (operation != 0);
    }
    
    static double Calculate (short operation, double num1, double num2) {
    	double result = 0;
    	switch (operation) {
    		case 1 -> //sum
    			result = num1 + num2;
    		case 2 -> //substration
    			result = num1 - num2;
    		case 3 -> //multiplication
    			result = num1 * num2;
    		case 4 -> //division
    			result = num1 / num2;
                //case 5 -> //square
                       // result = Math.pow(num, 2) ;
    	}
    	return result;
    }
    
    static boolean OperationExists (short operation) {
       	boolean Return = true;
    	if (operation > 5) {
       		System.out.println("ERROR: Operation chosen is invalid.\n");
       		Return = false;
       	}
    	return Return;
    }
    
    static boolean ValidatedInputData (short operation, double num1, double num2) {
    	boolean Return = true; 
    	if (operation == 4 & num2 == 0) {
        	 System.out.println("ERROR: Divisor cannot be zero.\n");
        	 Return = false;
        }
    	return Return;
    }
    
         static boolean ValidatedInputDataSquare (short operation, double num) {
    	boolean Return = true; 
    	if (operation == 5 & num < 0) {
        	 System.out.println("ERROR: value cannot be negative.\n");
        	 Return = false;
        }
    	return Return;
    }
    
    static String getNameOperation (short operation) {
    	
        return switch (operation) {
            case 1 -> "sum";
            case 2 -> "subtration";
            case 3 -> "multiplication";
            case 4 -> "division";
            case 5 -> "square";
            default -> "undefined";
        };
    	
    }
} 